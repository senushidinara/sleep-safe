import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import BottomNav from './components/BottomNav';

// Tab Components
import HomeTab from './components/tabs/HomeTab';
import MindRewireTab from './components/tabs/MindRewireTab';
import NeuroSyncTab from './components/tabs/NeuroSyncTab';
import ProgressTab from './components/tabs/ProgressTab';
import CommunityTab from './components/tabs/CommunityTab';

export type Tab = 'Home' | 'Mind' | 'Audio' | 'Progress' | 'Community';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('Home');

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'Home':
        return <HomeTab />;
      case 'Mind':
        return <MindRewireTab />;
      case 'Audio':
        return <NeuroSyncTab />;
      case 'Progress':
        return <ProgressTab />;
      case 'Community':
        return <CommunityTab />;
      default:
        return <HomeTab />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 text-slate-200 font-sans">
      <Header />
      <main className="pb-20"> {/* Add padding-bottom to avoid overlap with BottomNav */}
        {renderActiveTab()}
      </main>
      <Footer />
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default App;