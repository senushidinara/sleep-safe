import { GoogleGenAI, Content, GenerateContentResponse } from "@google/genai";
import { Message } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = "You are SleepSafe, a friendly and empathetic AI wellness coach specializing in Cognitive Behavioral Therapy for Insomnia (CBT-I). Your goal is to help users understand and overcome sleep procrastination and anxiety. Keep your responses concise, supportive, and actionable. Avoid giving medical advice and focus on behavioral and cognitive techniques. You should guide the user through identifying negative thought patterns, scheduling their sleep, and creating a relaxing bedtime routine.";

export const getAiCoachResponse = async (history: Message[]): Promise<string> => {
  try {
    const contents: Content[] = history
        .filter(msg => msg.role !== 'error')
        .map(msg => ({
            role: msg.role as 'user' | 'model',
            parts: [{ text: msg.text }],
        }));

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: contents,
        config: {
            systemInstruction: systemInstruction,
        },
    });
    
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get response from AI coach.");
  }
};