import React from 'react';

const CheckIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" {...props}><polyline points="20 6 9 17 4 12"></polyline></svg>
);

const PricingCard: React.FC<{
  plan: string;
  price: string;
  description: string;
  features: string[];
  isFeatured?: boolean;
}> = ({ plan, price, description, features, isFeatured = false }) => {
  return (
    <div className={`relative p-8 rounded-3xl border ${isFeatured ? 'bg-indigo-950/50 border-indigo-500' : 'bg-slate-800/50 border-slate-700'}`}>
      {isFeatured && <div className="absolute top-0 right-8 -mt-4 px-3 py-1 text-sm font-semibold text-white bg-indigo-600 rounded-full">Most Popular</div>}
      <h3 className="text-2xl font-semibold text-white">{plan}</h3>
      <p className="mt-2 text-slate-400">{description}</p>
      <p className="mt-6">
        <span className="text-4xl font-bold tracking-tight text-white">{price}</span>
        {price !== 'Free' && <span className="text-base font-medium text-slate-400">/month</span>}
      </p>
      <a 
        href="#" 
        aria-label={`Get started with the ${plan} plan`}
        className={`mt-8 block w-full py-3 px-6 text-center rounded-lg font-semibold ${isFeatured ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-slate-700 text-slate-100 hover:bg-slate-600'} transition-colors`}
      >
        Get started
      </a>
      <ul className="mt-8 space-y-4 text-sm text-slate-300">
        {features.map((feature, i) => (
          <li key={i} className="flex items-center gap-3">
            <CheckIcon className="h-5 w-5 text-indigo-400" aria-hidden="true" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const PricingSection: React.FC = () => {
  return (
    <section id="pricing" className="py-20 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Find the Plan That's Right for You</h2>
          <p className="mt-4 text-lg text-slate-300">
            Start for free, and unlock powerful features as you progress on your journey to better sleep.
          </p>
        </div>
        <div className="mt-16 max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          <PricingCard
            plan="Freemium"
            price="Free"
            description="Core tools to start your journey."
            features={['Core AI Sleep Coach', 'Basic Habit Tracking', 'Sleep Data Visualization']}
          />
          <PricingCard
            plan="Premium"
            price="$7.99"
            description="For a deeper, guided recovery."
            features={[
              'Everything in Freemium',
              'Advanced CBT Therapy Modules',
              'NeuroSync Audio System',
              'Sleep Guardian Automation',
              'Accountability Circles'
            ]}
            isFeatured={true}
          />
           <PricingCard
            plan="Enterprise"
            price="Custom"
            description="For teams and organizations."
            features={['Sleep Health Analytics', 'University & Company Plans', 'Dedicated Support']}
          />
        </div>
      </div>
    </section>
  );
};

export default PricingSection;