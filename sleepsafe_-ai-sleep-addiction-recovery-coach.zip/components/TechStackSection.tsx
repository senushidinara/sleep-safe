
import React from 'react';

const TechPill: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="inline-block bg-slate-700 text-slate-300 text-sm font-medium px-3 py-1 rounded-full">
    {children}
  </span>
);

const TechStackSection: React.FC = () => {
  return (
    <section className="py-20 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Built on a Modern Foundation</h2>
          <p className="mt-4 text-lg text-slate-300">
            We leverage a powerful, scalable, and secure technology stack to deliver a seamless and intelligent wellness experience.
          </p>
        </div>
        <div className="mt-12 max-w-4xl mx-auto p-8 bg-slate-800/50 rounded-2xl border border-slate-700/50">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-indigo-400">Frontend</h3>
              <div className="mt-4 flex flex-wrap gap-2">
                <TechPill>React</TechPill>
                <TechPill>Tailwind CSS</TechPill>
                <TechPill>Flutter</TechPill>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-indigo-400">Backend</h3>
              <div className="mt-4 flex flex-wrap gap-2">
                <TechPill>Python (FastAPI)</TechPill>
                <TechPill>Node.js</TechPill>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-indigo-400">AI Core</h3>
              <div className="mt-4 flex flex-wrap gap-2">
                <TechPill>Gemini</TechPill>
                <TechPill>TensorFlow</TechPill>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-indigo-400">Infrastructure</h3>
              <div className="mt-4 flex flex-wrap gap-2">
                <TechPill>PostgreSQL</TechPill>
                <TechPill>Redis</TechPill>
                <TechPill>BLE</TechPill>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechStackSection;
