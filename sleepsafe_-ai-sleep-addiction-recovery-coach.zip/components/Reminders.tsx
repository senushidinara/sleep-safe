import React, { useState, useEffect } from 'react';
import { Reminder } from '../types';
import { RepeatIcon } from './icons';

const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
);
const TrashIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

const Reminders: React.FC = () => {
    const [reminders, setReminders] = useState<Reminder[]>([]);
    const [task, setTask] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [repeat, setRepeat] = useState<'none' | 'daily' | 'weekly' | 'monthly'>('none');
    const [showForm, setShowForm] = useState(false);

    // Load reminders from local storage on initial render
    useEffect(() => {
        try {
            const storedReminders = localStorage.getItem('sleepReminders');
            if (storedReminders) {
                setReminders(JSON.parse(storedReminders));
            }
        } catch (error) {
            console.error("Failed to parse reminders from localStorage", error);
        }
    }, []);

    // Effect for handling notifications
    useEffect(() => {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }

        const checkReminders = () => {
            if (Notification.permission !== 'granted') return;
            
            const now = Date.now();
            reminders.forEach(reminder => {
                const reminderTime = new Date(reminder.datetime).getTime();
                // Notify if due within the last 60 seconds and not completed
                if (!reminder.completed && reminderTime <= now && (now - reminderTime) < 60000) {
                    const lastNotified = localStorage.getItem(`notified_${reminder.id}`);
                    if (lastNotified !== reminder.datetime) {
                        new Notification('SleepSafe Reminder', {
                            body: reminder.task,
                            icon: '/vite.svg', // A proper icon URL would be better
                        });
                        localStorage.setItem(`notified_${reminder.id}`, reminder.datetime);
                    }
                }
            });
        };

        const intervalId = setInterval(checkReminders, 30000); // Check every 30 seconds

        return () => clearInterval(intervalId); // Cleanup on component unmount
    }, [reminders]);
    
    const handleAddReminder = (e: React.FormEvent) => {
        e.preventDefault();
        if (!task.trim() || !date || !time) {
            alert("Please fill out all fields for the reminder.");
            return;
        }

        const newReminder: Reminder = {
            id: Date.now(),
            task: task.trim(),
            datetime: new Date(`${date}T${time}`).toISOString(),
            completed: false,
            repeat: repeat,
        };

        const updatedReminders = [...reminders, newReminder].sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime());
        setReminders(updatedReminders);
        localStorage.setItem('sleepReminders', JSON.stringify(updatedReminders));

        // Reset form
        setTask('');
        setDate('');
        setTime('');
        setRepeat('none');
        setShowForm(false);
    };

    const handleToggleComplete = (id: number) => {
        const reminderToUpdate = reminders.find(r => r.id === id);
        if (!reminderToUpdate) return;
        
        let updatedReminders;

        if (reminderToUpdate.repeat && reminderToUpdate.repeat !== 'none') {
            // Reschedule repeating reminder
            const nextDate = new Date(reminderToUpdate.datetime);
            switch (reminderToUpdate.repeat) {
                case 'daily': nextDate.setDate(nextDate.getDate() + 1); break;
                case 'weekly': nextDate.setDate(nextDate.getDate() + 7); break;
                case 'monthly': nextDate.setMonth(nextDate.getMonth() + 1); break;
            }
            updatedReminders = reminders.map(r => r.id === id ? { ...r, datetime: nextDate.toISOString() } : r);
        } else {
            // Complete a non-repeating reminder
            updatedReminders = reminders.map(r => r.id === id ? { ...r, completed: !r.completed } : r);
        }

        updatedReminders.sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime());
        setReminders(updatedReminders);
        localStorage.setItem('sleepReminders', JSON.stringify(updatedReminders));
    };

    const handleDeleteReminder = (id: number) => {
        const updatedReminders = reminders.filter(r => r.id !== id);
        setReminders(updatedReminders);
        localStorage.setItem('sleepReminders', JSON.stringify(updatedReminders));
        localStorage.removeItem(`notified_${id}`); // Clean up notification tracker
    };

    return (
        <div className="mt-4 space-y-4">
            {reminders.length > 0 && (
                <ul className="space-y-3 max-h-40 overflow-y-auto custom-scrollbar pr-2">
                    {reminders.map(reminder => (
                        <li key={reminder.id} className="flex items-center justify-between bg-slate-900/50 p-3 rounded-lg animate-fade-in">
                            <div className="flex items-center gap-3 flex-grow min-w-0">
                                <input 
                                    type="checkbox" 
                                    id={`reminder-${reminder.id}`}
                                    checked={reminder.completed}
                                    onChange={() => handleToggleComplete(reminder.id)}
                                    className="h-5 w-5 rounded bg-slate-700 border-slate-600 text-indigo-600 focus:ring-indigo-500 flex-shrink-0"
                                    aria-label={`Mark "${reminder.task}" as ${reminder.completed ? 'incomplete' : 'complete'}`}
                                />
                                <label htmlFor={`reminder-${reminder.id}`} className={`flex-grow min-w-0 cursor-pointer ${reminder.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                                    <span className="font-medium truncate block">{reminder.task}</span>
                                    <div className="flex items-center gap-2">
                                        {reminder.repeat && reminder.repeat !== 'none' && <RepeatIcon className="h-3 w-3 text-slate-400" />}
                                        <span className="block text-xs text-slate-400">
                                            {new Date(reminder.datetime).toLocaleString(undefined, {
                                                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
                                            })}
                                        </span>
                                    </div>
                                </label>
                            </div>
                            <button onClick={() => handleDeleteReminder(reminder.id)} aria-label={`Delete reminder: ${reminder.task}`} className="ml-2 text-slate-500 hover:text-red-400 transition-colors flex-shrink-0">
                                <TrashIcon className="h-5 w-5" />
                            </button>
                        </li>
                    ))}
                </ul>
            )}

            {showForm ? (
                <form onSubmit={handleAddReminder} className="p-4 bg-slate-900/50 rounded-lg space-y-3 animate-fade-in">
                    <div>
                        <label htmlFor="reminder-task" className="sr-only">Reminder Details</label>
                        <input type="text" id="reminder-task" value={task} onChange={e => setTask(e.target.value)} placeholder="e.g., Read a book" className="w-full px-3 py-2 bg-slate-700 text-slate-200 rounded-md focus:outline-none" required/>
                    </div>
                    <div className="flex gap-2">
                         <div className="flex-1">
                            <label htmlFor="reminder-date" className="sr-only">Date</label>
                            <input type="date" id="reminder-date" value={date} min={new Date().toISOString().split("T")[0]} onChange={e => setDate(e.target.value)} className="w-full px-3 py-2 bg-slate-700 text-slate-200 rounded-md focus:outline-none" required/>
                        </div>
                        <div className="flex-1">
                            <label htmlFor="reminder-time" className="sr-only">Time</label>
                            <input type="time" id="reminder-time" value={time} onChange={e => setTime(e.target.value)} className="w-full px-3 py-2 bg-slate-700 text-slate-200 rounded-md focus:outline-none" required/>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="reminder-repeat" className="sr-only">Repeat Frequency</label>
                        <select id="reminder-repeat" value={repeat} onChange={e => setRepeat(e.target.value as any)} className="w-full px-3 py-2 bg-slate-700 text-slate-200 rounded-md focus:outline-none appearance-none" style={{ backgroundPosition: 'right 0.5rem center', backgroundSize: '1.5em 1.5em', backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%239ca3af' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")` }}>
                            <option value="none">Does not repeat</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                        </select>
                    </div>
                    <div className="flex justify-end gap-2">
                         <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-500 transition-colors text-sm">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 transition-colors text-sm">Add Reminder</button>
                    </div>
                </form>
            ) : (
                <button onClick={() => setShowForm(true)} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600/20 text-indigo-300 font-semibold rounded-lg hover:bg-indigo-600/30 transition-colors">
                    <PlusIcon className="h-5 w-5" />
                    Add a new reminder
                </button>
            )}
            {reminders.length === 0 && !showForm && <p className="text-center text-slate-500 py-2">No reminders set yet.</p>}
        </div>
    );
};

export default Reminders;
