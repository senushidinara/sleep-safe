import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900/50 pt-12 pb-32"> {/* Extra padding bottom for nav bar */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
        <p>&copy; {new Date().getFullYear()} SleepSafe. All rights reserved.</p>
        <p className="mt-1">Healing starts when you finally let yourself rest.</p>
      </div>
    </footer>
  );
};

export default Footer;