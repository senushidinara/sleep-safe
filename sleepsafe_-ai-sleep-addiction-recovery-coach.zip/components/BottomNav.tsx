import React from 'react';
import { HomeIcon, BrainIcon, MusicIcon, ChartIcon, UsersIcon } from './icons';
import { Tab } from '../App';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const navItems = [
  { name: 'Home', icon: HomeIcon, tab: 'Home' as Tab },
  { name: 'Mind Rewire', icon: BrainIcon, tab: 'Mind' as Tab },
  { name: 'NeuroSync', icon: MusicIcon, tab: 'Audio' as Tab },
  { name: 'Progress', icon: ChartIcon, tab: 'Progress' as Tab },
  { name: 'Community', icon: UsersIcon, tab: 'Community' as Tab },
];

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-sm border-t border-slate-700/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-around h-16">
          {navItems.map((item) => {
            const isActive = activeTab === item.tab;
            return (
              <button
                key={item.name}
                onClick={() => setActiveTab(item.tab)}
                aria-label={item.name}
                aria-current={isActive ? 'page' : undefined}
                className={`flex flex-col items-center justify-center w-full text-xs font-medium transition-colors duration-200 ${
                  isActive ? 'text-indigo-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <item.icon className="h-6 w-6 mb-1" />
                <span>{item.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

export default BottomNav;