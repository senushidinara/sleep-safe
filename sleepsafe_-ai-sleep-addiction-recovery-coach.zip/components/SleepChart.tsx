import React from 'react';
import { SleepLog } from '../types';
import { StarIcon } from './icons';

interface SleepChartProps {
  logs: SleepLog[];
  bedtimeGoal?: string;
}

const SleepChart: React.FC<SleepChartProps> = ({ logs, bedtimeGoal }) => {
  const maxDuration = Math.max(...logs.map(log => log.duration), 8); // Ensure a minimum height of 8 hours
  const chartHeight = 150;

  return (
    <div className="bg-slate-900/50 p-4 rounded-lg">
      <div className="flex items-end h-[150px] gap-2">
        {logs.slice(-15).map(log => {
          const barHeight = (log.duration / maxDuration) * chartHeight;
          let barColor = 'bg-indigo-500';
          if (log.quality === 'Excellent') barColor = 'bg-green-500';
          if (log.quality === 'Fair') barColor = 'bg-yellow-500';
          if (log.quality === 'Poor') barColor = 'bg-red-500';

          const goalMet = bedtimeGoal && log.bedtime && log.bedtime <= bedtimeGoal;

          return (
            <div key={log.id} className="relative flex-1 flex flex-col items-center gap-1 group">
              {goalMet && (
                <div className="absolute -top-5 z-10 text-yellow-400" title="Bedtime goal met!">
                  <StarIcon className="w-4 h-4" style={{ fill: 'currentColor' }} />
                </div>
              )}
              <div 
                className={`w-full rounded-t-sm transition-all duration-300 ${barColor} group-hover:opacity-80`}
                style={{ height: `${barHeight}px` }}
                title={`${log.duration.toFixed(1)} hrs on ${log.date}`}
              ></div>
              <span className="text-xs text-slate-500">{log.date.split(' ')[0]}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SleepChart;