import React from 'react';
import FeatureCard from './FeatureCard';

const ShieldIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
);
const BotIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
);
const WatchIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><circle cx="12" cy="12" r="7"/><polyline points="12 9 12 12 13.5 13.5"/><path d="M16.51 17.35l-.35 3.83a2 2 0 0 1-2 1.82H9.83a2 2 0 0 1-2-1.82l-.35-3.83m.01-10.7.35-3.83A2 2 0 0 1 9.83 1h4.35a2 2 0 0 1 2 1.82l.35 3.83"/></svg>
);
const WavesIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/></svg>
);
const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
);

const features = [
  {
    icon: <ShieldIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />,
    title: 'Sleep Guardian Mode',
    description: 'Detects late-night doomscrolling and gently intervenes by locking distracting apps and playing soothing ambient audio.',
  },
  {
    icon: <BotIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />,
    title: 'AI Cognitive Coach',
    description: 'Conversational AI trained in CBT to help you identify emotional triggers and develop healthier pre-sleep routines.',
  },
  {
    icon: <WatchIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />,
    title: 'SleepSafe Band',
    description: 'Optional hardware that tracks key biometrics and emits a gentle "SleepPulse" to cue your body for relaxation.',
  },
  {
    icon: <WavesIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />,
    title: 'NeuroSync Audio System',
    description: 'Adaptive soundscapes and binaural beats that retrain your circadian rhythm through frequency conditioning.',
  },
  {
    icon: <UsersIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />,
    title: 'Accountability Circles',
    description: 'Connect with others in anonymized, AI-moderated small groups for peer motivation and emotional support.',
  },
];

const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="py-20 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">A Smarter Way to Wind Down</h2>
          <p className="mt-4 text-lg text-slate-300">
            SleepSafe is more than a tracker. It's an active partner in your journey to better rest, using technology to heal, not hinder.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.slice(0, 3).map((feature) => (
            <FeatureCard key={feature.title} icon={feature.icon} title={feature.title} description={feature.description} />
          ))}
           <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-8">
             {features.slice(3).map((feature) => (
                <FeatureCard key={feature.title} icon={feature.icon} title={feature.title} description={feature.description} />
             ))}
           </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;