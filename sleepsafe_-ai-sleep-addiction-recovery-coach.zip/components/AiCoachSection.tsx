import React, { useState, useRef, useEffect } from 'react';
import { Message, SleepLog } from '../types';
import { getAiCoachResponse } from '../services/geminiService';

const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);
const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" /></svg>
);

const AiCoachSection: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Hello! I'm your SleepSafe AI Coach. What's on your mind tonight?" }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>([]);
  const [sleepDuration, setSleepDuration] = useState('');
  const [sleepQuality, setSleepQuality] = useState<'Good' | 'Fair' | 'Poor' | 'Excellent'>('Good');
  const [bedtime, setBedtime] = useState('');


  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    try {
      const storedLogs = localStorage.getItem('sleepLogs');
      if (storedLogs) {
        setSleepLogs(JSON.parse(storedLogs));
      }
    } catch (error) {
      console.error("Failed to parse sleep logs from localStorage", error);
    }
  }, []);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isLoading) return;

    const newHistory: Message[] = [...messages, { role: 'user', text: userInput }];
    setMessages(newHistory);
    setUserInput('');
    setIsLoading(true);

    try {
      const responseText = await getAiCoachResponse(newHistory);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setMessages(prev => [...prev, { role: 'error', text: errorMessage }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogSleep = (e: React.FormEvent) => {
    e.preventDefault();
    const duration = parseFloat(sleepDuration);
    if (!duration || duration <= 0 || duration > 24) {
      alert("Please enter a valid sleep duration (0-24 hours).");
      return;
    }
    if (!bedtime) {
      alert("Please enter your bedtime.");
      return;
    }

    const newLog: SleepLog = {
      id: Date.now(),
      date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      duration: duration,
      quality: sleepQuality,
      bedtime: bedtime,
    };

    const updatedLogs = [...sleepLogs, newLog];
    setSleepLogs(updatedLogs);
    localStorage.setItem('sleepLogs', JSON.stringify(updatedLogs));

    setSleepDuration('');
    setSleepQuality('Good');
    setBedtime('');
  };

  return (
    <section id="coach" className="py-20 sm:py-32 bg-slate-900/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Your Personal Wellness Hub</h2>
          <p className="mt-4 text-lg text-slate-300">
            Chat with your AI coach about your day, then log your sleep to track your progress over time.
          </p>
        </div>

        <div className="mt-12 max-w-2xl mx-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl shadow-indigo-900/20 flex flex-col h-[60vh] max-h-[700px]">
            <div role="log" aria-live="polite" className="flex-1 p-6 space-y-6 overflow-y-auto custom-scrollbar">
              {messages.map((msg, index) => (
                <div key={index} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  {msg.role !== 'user' && (
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center" aria-hidden="true">
                      <MoonIcon className="w-6 h-6 text-white"/>
                    </div>
                  )}
                  <div className={`max-w-md p-4 rounded-2xl ${
                    msg.role === 'user' ? 'bg-indigo-500 text-white rounded-br-none' : 
                    msg.role === 'error' ? 'bg-red-500/20 text-red-300 border border-red-500/50 rounded-bl-none' : 
                    'bg-slate-700 text-slate-200 rounded-bl-none'
                  }`}>
                    <p className="text-sm">{msg.text}</p>
                  </div>
                   {msg.role === 'user' && (
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-slate-600 flex items-center justify-center" aria-hidden="true">
                        <UserIcon className="w-6 h-6 text-white"/>
                    </div>
                  )}
                </div>
              ))}
              {isLoading && (
                 <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center" aria-hidden="true">
                        <MoonIcon className="w-6 h-6 text-white"/>
                    </div>
                    <div className="max-w-md p-4 rounded-2xl bg-slate-700 text-slate-200 rounded-bl-none">
                        <div role="status" aria-label="Loading response">
                           <div className="flex items-center justify-center space-x-2">
                              <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse"></div>
                              <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:0.2s]"></div>
                              <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:0.4s]"></div>
                           </div>
                        </div>
                    </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="p-4 border-t border-slate-700">
              <form onSubmit={handleSendMessage} className="flex items-center gap-4">
                <label htmlFor="chat-input" className="sr-only">Your Message</label>
                <input
                  id="chat-input"
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 w-full px-4 py-3 bg-slate-700 text-slate-200 rounded-full focus:outline-none transition"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  aria-label="Send message"
                  disabled={isLoading || !userInput.trim()}
                  className="flex-shrink-0 w-12 h-12 bg-indigo-600 rounded-full text-white flex items-center justify-center hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="mt-16 max-w-2xl mx-auto">
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-xl font-semibold text-white">Log Your Sleep</h3>
            <p className="text-sm text-slate-400 mt-1">How did you sleep last night?</p>
            <form onSubmit={handleLogSleep} className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
              <div className="w-full">
                  <label htmlFor="duration" className="block text-xs font-medium text-slate-400 mb-1">Duration (hours)</label>
                  <input
                    id="duration"
                    type="number"
                    step="0.1"
                    value={sleepDuration}
                    onChange={(e) => setSleepDuration(e.target.value)}
                    placeholder="e.g., 7.5"
                    className="w-full px-4 py-2 bg-slate-700 text-slate-200 rounded-lg focus:outline-none"
                    required
                  />
              </div>
              <div className="w-full">
                  <label htmlFor="bedtime" className="block text-xs font-medium text-slate-400 mb-1">Bedtime</label>
                  <input
                    id="bedtime"
                    type="time"
                    value={bedtime}
                    onChange={(e) => setBedtime(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-700 text-slate-200 rounded-lg focus:outline-none"
                    required
                  />
              </div>
              <div className="w-full">
                 <label htmlFor="quality" className="block text-xs font-medium text-slate-400 mb-1">Sleep Quality</label>
                 <select
                   id="quality"
                   value={sleepQuality}
                   onChange={(e) => setSleepQuality(e.target.value as any)}
                   className="w-full px-4 py-2 bg-slate-700 text-slate-200 rounded-lg focus:outline-none appearance-none"
                   style={{ backgroundPosition: 'right 0.5rem center', backgroundSize: '1.5em 1.5em', backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%239ca3af' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")` }}
                 >
                   <option>Good</option>
                   <option>Fair</option>
                   <option>Poor</option>
                   <option>Excellent</option>
                 </select>
              </div>
              <button
                type="submit"
                className="w-full sm:col-span-3 px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 disabled:bg-slate-600 transition-colors"
              >
                Log Sleep
              </button>
            </form>
          </div>
          <div className="mt-6">
             <h4 id="recent-logs-heading" className="text-lg font-semibold text-slate-300 mb-3">Recent Logs</h4>
             <ul aria-labelledby="recent-logs-heading" className="space-y-3 max-h-48 overflow-y-auto custom-scrollbar pr-2">
                {sleepLogs.length > 0 ? (
                    [...sleepLogs].reverse().map(log => (
                        <li key={log.id}>
                            <div className="bg-slate-800 p-4 rounded-lg flex justify-between items-center animate-fade-in">
                                <div>
                                    <p className="font-semibold text-slate-200">
                                      <time dateTime={new Date(log.id).toISOString().split('T')[0]}>{log.date}</time>
                                      {log.bedtime && <span className="text-sm text-slate-400 ml-2">{new Date(`1970-01-01T${log.bedtime}`).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
                                    </p>
                                    <p className="text-sm text-slate-400">Quality: {log.quality}</p>
                                </div>
                                <p className="text-lg font-bold text-indigo-400">{log.duration.toFixed(1)} hrs</p>
                            </div>
                        </li>
                    ))
                ) : (
                    <li>
                      <p className="text-center text-slate-500 py-4">No sleep data logged yet.</p>
                    </li>
                )}
             </ul>
          </div>
        </div>

      </div>
    </section>
  );
};

export default AiCoachSection;