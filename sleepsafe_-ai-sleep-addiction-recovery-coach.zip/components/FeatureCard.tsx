
import React from 'react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="relative p-8 bg-slate-800/50 rounded-2xl border border-slate-700/50 overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(128,90,213,0.15),rgba(255,255,255,0))]"></div>
        <div className="relative z-10">
            <div className="flex-shrink-0">
                {icon}
            </div>
            <h3 className="mt-6 text-xl font-semibold text-white">{title}</h3>
            <p className="mt-2 text-base text-slate-300">{description}</p>
        </div>
    </div>
  );
};

export default FeatureCard;
