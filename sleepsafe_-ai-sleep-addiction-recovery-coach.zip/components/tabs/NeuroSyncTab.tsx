import React, { useState } from 'react';
import { MusicIcon, StarIcon } from '../icons';

const soundscapes = [
  { title: 'Rainforest Ambience', description: 'Calming sounds of the jungle to ease your mind.', duration: '30 min' },
  { title: 'Deep Ocean Waves', description: 'Gentle waves and deep rumbles for profound relaxation.', duration: '45 min' },
  { title: 'Binaural Delta Waves', description: 'Scientifically designed frequencies to induce deep sleep.', duration: '60 min', recommended: true },
  { title: 'Cozy Campfire', description: 'The warm crackle of a fire under a starry sky.', duration: '30 min' },
  { title: 'Silent Night Wind', description: 'A soft, whispering wind to clear your thoughts.', duration: '25 min' },
];

const PlayIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M8 5v14l11-7z"></path></svg>
);
const PauseIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"></path></svg>
);


const NeuroSyncTab: React.FC = () => {
    const [playing, setPlaying] = useState<string | null>(null);

    const togglePlay = (title: string) => {
        setPlaying(prev => (prev === title ? null : title));
    }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white">NeuroSync Audio Lab</h1>
        <p className="mt-2 text-lg text-slate-300">Choose a soundscape to condition your brain for restful sleep.</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-4">
        {soundscapes.map(item => (
          <div key={item.title} className={`relative bg-slate-800/50 border rounded-lg p-4 flex items-center justify-between transition-all duration-300 hover:bg-slate-800 ${item.recommended ? 'border-indigo-500/50' : 'border-slate-700/50'}`}>
            {item.recommended && (
                 <div className="absolute top-0 right-4 -mt-3 px-3 py-1 text-xs font-semibold text-white bg-indigo-600 rounded-full flex items-center gap-1">
                    <StarIcon className="w-3 h-3"/>
                    Today's Recommendation
                </div>
            )}
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center">
                  <MusicIcon className="w-6 h-6 text-indigo-400"/>
              </div>
              <div>
                <h3 className="font-semibold text-white">{item.title}</h3>
                <p className="text-sm text-slate-400">{item.description}</p>
              </div>
            </div>
            <button 
                onClick={() => togglePlay(item.title)}
                aria-label={playing === item.title ? `Pause ${item.title}` : `Play ${item.title}`}
                className="flex-shrink-0 w-12 h-12 bg-indigo-600 rounded-full text-white flex items-center justify-center hover:bg-indigo-500 disabled:bg-slate-600 transition-colors"
            >
                {playing === item.title ? <PauseIcon className="w-6 h-6" /> : <PlayIcon className="w-6 h-6" />}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NeuroSyncTab;