import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../../types';
import { getAiCoachResponse } from '../../services/geminiService';
import { MicIcon, MessageCircleIcon } from '../icons';

// Add SpeechRecognition type to window
// Fix for TS2304: Cannot find name 'SpeechRecognition'.
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message: string;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  [index: number]: SpeechRecognitionResult;
  length: number;
  item(index: number): SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
  isFinal: boolean;
  length: number;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: () => void;
  onend: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);
const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" /></svg>
);

const conversationStarters = [
    "I can't stop thinking about work.",
    "I feel anxious about tomorrow.",
    "What's a good way to relax right now?",
    "I stayed up too late again last night.",
];

const MindRewireTab: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Hello! I'm your SleepSafe AI Coach. Let's talk about what's on your mind. How have you been feeling about your sleep lately?" }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsRecording(true);
        setSpeechError(null);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setSpeechError("Microphone access was denied. Please enable it in your browser settings.");
        } else {
          setSpeechError("Speech recognition failed. Please try again.");
        }
        setIsRecording(false);
      };

      recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join('');
        setUserInput(transcript);
        if (event.results[0].isFinal) {
             handleSendMessage(null, transcript);
        }
      };
      
      recognitionRef.current = recognition;
    }
  }, []);

  const handleMicClick = () => {
    if (!recognitionRef.current) return;

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      setUserInput(''); // Clear input before starting
      recognitionRef.current.start();
    }
  };

  const handleSendMessage = async (e: React.FormEvent | null, messageText?: string) => {
    e?.preventDefault();
    const textToSend = messageText || userInput;
    if (!textToSend.trim() || isLoading) return;

    const newHistory: Message[] = [...messages, { role: 'user', text: textToSend }];
    setMessages(newHistory);
    setUserInput('');
    setIsLoading(true);

    try {
      const responseText = await getAiCoachResponse(newHistory);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      const errorMessage = "Sorry, I'm having trouble connecting right now. Please try again in a moment.";
      setMessages(prev => [...prev, { role: 'error', text: errorMessage }]);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleStarterClick = (starter: string) => {
      handleSendMessage(null, starter);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white">Mind Rewire</h1>
        <p className="mt-2 text-lg text-slate-300">Chat with your AI coach to identify and reframe thoughts about sleep.</p>
      </div>

      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl shadow-indigo-900/20 flex flex-col h-[calc(100vh-20rem)] max-h-[700px] min-h-[400px]">
          <div role="log" aria-live="polite" className="flex-1 p-6 space-y-6 overflow-y-auto custom-scrollbar">
            {messages.length === 1 && (
                <div className="p-4 bg-slate-900/50 rounded-lg">
                    <h3 className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                        <MessageCircleIcon className="w-4 h-4" />
                        Conversation Starters
                    </h3>
                    <div className="flex flex-wrap gap-2">
                        {conversationStarters.map(starter => (
                            <button key={starter} onClick={() => handleStarterClick(starter)} className="text-xs bg-slate-700 hover:bg-slate-600 text-slate-200 px-3 py-1 rounded-full transition-colors">
                                "{starter}"
                            </button>
                        ))}
                    </div>
                </div>
            )}
            {messages.map((msg, index) => (
              <div key={index} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                {msg.role !== 'user' && (
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center" aria-hidden="true">
                    <MoonIcon className="w-6 h-6 text-white"/>
                  </div>
                )}
                <div className={`max-w-md p-4 rounded-2xl ${
                  msg.role === 'user' ? 'bg-indigo-500 text-white rounded-br-none' : 
                  msg.role === 'error' ? 'bg-red-500/20 text-red-300 border border-red-500/50 rounded-bl-none' : 
                  'bg-slate-700 text-slate-200 rounded-bl-none'
                }`}>
                  <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                </div>
                 {msg.role === 'user' && (
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-slate-600 flex items-center justify-center" aria-hidden="true">
                      <UserIcon className="w-6 h-6 text-white"/>
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
               <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center" aria-hidden="true">
                      <MoonIcon className="w-6 h-6 text-white"/>
                  </div>
                  <div className="max-w-md p-4 rounded-2xl bg-slate-700 text-slate-200 rounded-bl-none">
                      <div role="status" aria-label="Loading response">
                         <div className="flex items-center justify-center space-x-2">
                            <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse"></div>
                            <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:0.2s]"></div>
                            <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:0.4s]"></div>
                         </div>
                      </div>
                  </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="p-4 border-t border-slate-700">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2" aria-label="Chat input form">
              <label htmlFor="chat-input" className="sr-only">Your Message</label>
              <input
                ref={inputRef}
                id="chat-input"
                type="text"
                value={userInput}
                onChange={(e) => {
                    setUserInput(e.target.value);
                    if (speechError) setSpeechError(null);
                }}
                placeholder={isRecording ? "Listening..." : "Type or record a message..."}
                className="flex-1 w-full px-4 py-3 bg-slate-700 text-slate-200 rounded-full focus:outline-none transition"
                disabled={isLoading}
                autoComplete="off"
              />
              {recognitionRef.current && (
                <button
                  type="button"
                  onClick={handleMicClick}
                  aria-label={isRecording ? 'Stop recording' : 'Record voice message'}
                  aria-pressed={isRecording}
                  className={`flex-shrink-0 w-12 h-12 rounded-full text-white flex items-center justify-center transition-colors ${
                    isRecording
                      ? 'bg-red-600 hover:bg-red-500 animate-pulse-mic'
                      : 'bg-slate-600 hover:bg-slate-500'
                  }`}
                >
                  <MicIcon className="h-6 w-6" />
                </button>
              )}
              <button
                type="submit"
                aria-label="Send message"
                disabled={isLoading || !userInput.trim()}
                className="flex-shrink-0 w-12 h-12 bg-indigo-600 rounded-full text-white flex items-center justify-center hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
              </button>
            </form>
            {speechError && <p role="alert" className="text-xs text-red-400 text-center mt-2">{speechError}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MindRewireTab;