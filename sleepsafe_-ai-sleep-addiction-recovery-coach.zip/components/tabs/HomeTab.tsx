import React, { useState, useEffect } from 'react';
import { ShieldIcon, UsersIcon, ClockIcon, LightbulbIcon, SunIcon, BedIcon, ZapIcon, CheckCircleIcon } from '../icons';
import Reminders from '../Reminders';
import { SleepLog } from '../../types';

const DashboardCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
  children?: React.ReactNode;
}> = ({ icon, title, description, children }) => (
  <div className="relative p-6 bg-slate-800/50 rounded-2xl border border-slate-700/50">
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0">{icon}</div>
      <div>
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        <p className="mt-1 text-sm text-slate-300">{description}</p>
      </div>
    </div>
    {children && <div className="mt-4">{children}</div>}
  </div>
);

const sleepTips = [
    { icon: <SunIcon className="h-6 w-6 text-yellow-400" />, text: "Get 10-15 minutes of morning sunlight to set your body clock." },
    { icon: <BedIcon className="h-6 w-6 text-sky-400" />, text: "Try to go to bed and wake up around the same time each day." },
    { icon: <ZapIcon className="h-6 w-6 text-amber-400" />, text: "Avoid caffeine and large meals within a few hours of bedtime." },
];

const eveningChecklist = [
    { text: "Set a reminder for your screen-off time." },
    { text: "Listen to a calming NeuroSync soundscape." },
    { text: "Chat with your AI coach about your day." },
    { text: "Log your sleep when you wake up." },
];

const calculateStreak = (logs: SleepLog[]): number => {
    if (!logs || logs.length === 0) return 0;

    const logDates = new Set(logs.map(log => {
        const d = new Date(log.id);
        d.setHours(0, 0, 0, 0); // Normalize to start of day
        return d.toISOString().split('T')[0];
    }));

    let streak = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    // If there's no log for today, start checking from yesterday.
    if (!logDates.has(currentDate.toISOString().split('T')[0])) {
        currentDate.setDate(currentDate.getDate() - 1);
    }

    while (logDates.has(currentDate.toISOString().split('T')[0])) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
    }

    return streak;
};

const HomeTab: React.FC = () => {
    const [streak, setStreak] = useState(0);

    useEffect(() => {
        try {
            const storedLogs = localStorage.getItem('sleepLogs');
            if (storedLogs) {
                const logs: SleepLog[] = JSON.parse(storedLogs);
                setStreak(calculateStreak(logs));
            }
        } catch (error) {
            console.error("Failed to calculate streak from localStorage", error);
        }
    }, []);


  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-100 to-indigo-300 tracking-tight">
          Welcome Back
        </h1>
        <p className="mt-4 text-lg text-slate-300 max-w-2xl mx-auto">
          Your journey to better sleep continues. Here's your dashboard.
        </p>
      </div>
      
      <div className="max-w-3xl mx-auto grid grid-cols-1 gap-6">
        <DashboardCard
          icon={<CheckCircleIcon className="h-8 w-8 text-indigo-400" />}
          title="Evening Wind-Down Checklist"
          description="Actionable steps for a restful night."
        >
            <ul className="space-y-3">
                {eveningChecklist.map((item, index) => (
                    <li key={index} className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-lg">
                        <div className="flex-shrink-0">
                            <CheckCircleIcon className="w-5 h-5 text-green-400" />
                        </div>
                        <span className="text-sm text-slate-300">{item.text}</span>
                    </li>
                ))}
            </ul>
        </DashboardCard>

        <DashboardCard
          icon={<UsersIcon className="h-8 w-8 text-indigo-400" />}
          title="Sleep Streak"
          description="Maintain consistency by logging your sleep daily."
        >
          <div className="flex items-center justify-center text-center p-4 bg-slate-900/50 rounded-lg">
            <div>
              <p className="text-4xl font-bold text-indigo-400">{streak}</p>
              <p className="text-sm text-slate-400">Day Streak</p>
            </div>
          </div>
        </DashboardCard>
        
        <DashboardCard
          icon={<ClockIcon className="h-8 w-8 text-indigo-400" />}
          title="Bedtime Reminders"
          description="Set custom reminders for your wind-down routine."
        >
          <Reminders />
        </DashboardCard>
        
        <DashboardCard
          icon={<LightbulbIcon className="h-8 w-8 text-indigo-400" />}
          title="Quick Sleep Tips"
          description="Small habits for a big impact on your rest."
        >
            <ul className="space-y-3">
                {sleepTips.map((tip, index) => (
                    <li key={index} className="flex items-center gap-4 p-3 bg-slate-900/50 rounded-lg">
                        <div className="flex-shrink-0">{tip.icon}</div>
                        <span className="text-sm text-slate-300">{tip.text}</span>
                    </li>
                ))}
            </ul>
        </DashboardCard>
        
        <DashboardCard
          icon={<ShieldIcon className="h-8 w-8 text-indigo-400" />}
          title="Sleep Guardian"
          description="Your automated shield against late-night distractions."
        >
          <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded-lg">
            <span className="font-medium">Guardian Mode</span>
            <label htmlFor="guardian-toggle" className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" id="guardian-toggle" className="sr-only peer" />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        </DashboardCard>

      </div>
    </div>
  );
};

export default HomeTab;