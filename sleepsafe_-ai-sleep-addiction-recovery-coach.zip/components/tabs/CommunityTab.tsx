import React from 'react';
import { SparklesIcon, MessageCircleIcon, HandshakeIcon } from '../icons';

const communityPosts = [
  { author: 'NightOwl22', title: "Struggling with 'one more episode' syndrome. Any tips?", replies: 12, group: 'Late Night Warriors' },
  { author: 'EarlyBird_Hope', title: "Just completed a 7-day streak of sleeping before midnight!", replies: 25, group: 'Sunrise Squad' },
  { author: 'AnxiousSleeper', title: "How do you all deal with racing thoughts at bedtime?", replies: 18, group: 'Mindful Rest' },
  { author: 'Admin', title: "Weekly Challenge: 30 minutes of screen-free time before bed.", replies: 42, group: 'Announcements' },
];

const participationActions = [
    { icon: <SparklesIcon className="w-6 h-6 text-amber-400" />, title: "Share a recent success", description: "Did you meet your bedtime goal? Share it!" },
    { icon: <MessageCircleIcon className="w-6 h-6 text-sky-400" />, title: "Ask a question", description: "Struggling with something? Ask the community." },
    { icon: <HandshakeIcon className="w-6 h-6 text-emerald-400" />, title: "Welcome a new member", description: "Help someone feel at home." },
];

const CommunityTab: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white">Sleep Circles</h1>
        <p className="mt-2 text-lg text-slate-300">Connect with peers for support and accountability. You are not alone.</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        <div>
            <h2 className="text-xl font-semibold text-white mb-4">Ways to Participate</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {participationActions.map(action => (
                    <div key={action.title} className="bg-slate-800/50 p-4 rounded-lg text-center border border-slate-700/50 hover:bg-slate-800 transition-colors">
                        <div className="flex justify-center mb-2">{action.icon}</div>
                        <h3 className="font-semibold text-sm text-white">{action.title}</h3>
                        <p className="text-xs text-slate-400 mt-1">{action.description}</p>
                    </div>
                ))}
            </div>
        </div>

        <div>
            <h2 className="text-xl font-semibold text-white mb-4">Recent Discussions</h2>
            <div className="space-y-4">
                {communityPosts.map(post => (
                    <div key={post.title} className="bg-slate-800/50 border border-slate-700/50 rounded-lg p-4 transition-all duration-300 hover:border-indigo-500/50">
                        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                        <span>From: <span className="font-semibold text-indigo-400">{post.group}</span></span>
                        <span>by @{post.author}</span>
                        </div>
                        <h3 className="font-semibold text-white text-lg">{post.title}</h3>
                        <div className="mt-3 text-sm text-slate-500">
                        {post.replies} replies
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityTab;