import React, { useState, useEffect } from 'react';
import { SleepLog } from '../../types';
import SleepChart from '../SleepChart';
import { ClockIcon, StarIcon, TrendingUpIcon, LightbulbIcon } from '../icons';

const StatCard: React.FC<{
    icon: React.ReactNode;
    label: string;
    value: string;
    color: string;
}> = ({ icon, label, value, color }) => (
    <div className="bg-slate-800/50 p-4 rounded-lg flex items-center gap-4">
        <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center ${color}`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-400">{label}</p>
            <p className="text-xl font-bold text-white">{value}</p>
        </div>
    </div>
);


const ProgressTab: React.FC = () => {
    const [logs, setLogs] = useState<SleepLog[]>([]);
    const [avgDuration, setAvgDuration] = useState(0);
    const [avgQuality, setAvgQuality] = useState('N/A');
    const [bedtimeGoal, setBedtimeGoal] = useState<string>('23:00');
    const [goalAdherence, setGoalAdherence] = useState(0);

    useEffect(() => {
        try {
            const storedLogs = localStorage.getItem('sleepLogs');
            const storedGoal = localStorage.getItem('bedtimeGoal');

            if (storedGoal) {
                setBedtimeGoal(JSON.parse(storedGoal));
            }
            
            if (storedLogs) {
                const parsedLogs: SleepLog[] = JSON.parse(storedLogs);
                setLogs(parsedLogs);
                
                if (parsedLogs.length > 0) {
                    // Calculate averages
                    const totalDuration = parsedLogs.reduce((acc, log) => acc + log.duration, 0);
                    setAvgDuration(totalDuration / parsedLogs.length);
                    
                    const qualityMap: { [key: string]: number } = { 'Poor': 1, 'Fair': 2, 'Good': 3, 'Excellent': 4 };
                    const qualityValues = Object.keys(qualityMap);
                    const totalQuality = parsedLogs.reduce((acc, log) => acc + (qualityMap[log.quality] || 2), 0);
                    const avgQualityValue = Math.round(totalQuality / parsedLogs.length);
                    const avgQualityString = qualityValues[avgQualityValue - 1] || 'N/A';
                    setAvgQuality(avgQualityString);

                    // Calculate goal adherence
                    const goal = storedGoal ? JSON.parse(storedGoal) : '23:00';
                    const { goalMetCount, logsWithBedtimeCount } = parsedLogs.reduce(
                        (acc, log) => {
                          if (log.bedtime) {
                            acc.logsWithBedtimeCount++;
                            if (log.bedtime <= goal) {
                              acc.goalMetCount++;
                            }
                          }
                          return acc;
                        },
                        { goalMetCount: 0, logsWithBedtimeCount: 0 }
                    );
                    const adherence = logsWithBedtimeCount > 0 ? Math.round((goalMetCount / logsWithBedtimeCount) * 100) : 0;
                    setGoalAdherence(adherence);
                }
            }
        } catch (error) {
            console.error("Failed to parse data from localStorage", error);
        }
    }, []);

    const handleGoalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newGoal = e.target.value;
        setBedtimeGoal(newGoal);
        localStorage.setItem('bedtimeGoal', JSON.stringify(newGoal));

        // Recalculate adherence
        if (logs.length > 0) {
            const { goalMetCount, logsWithBedtimeCount } = logs.reduce(
                (acc, log) => {
                  if (log.bedtime) {
                    acc.logsWithBedtimeCount++;
                    if (log.bedtime <= newGoal) {
                      acc.goalMetCount++;
                    }
                  }
                  return acc;
                },
                { goalMetCount: 0, logsWithBedtimeCount: 0 }
            );
            const adherence = logsWithBedtimeCount > 0 ? Math.round((goalMetCount / logsWithBedtimeCount) * 100) : 0;
            setGoalAdherence(adherence);
        }
    };
    
    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
            <div className="text-center mb-8">
                <h1 className="text-3xl font-bold tracking-tight text-white">Your Progress</h1>
                <p className="mt-2 text-lg text-slate-300">Visualize your journey to better, more consistent sleep.</p>
            </div>

            <div className="max-w-3xl mx-auto">
                 <div className="bg-slate-800/50 p-6 rounded-lg mb-8">
                     <h3 className="text-lg font-semibold text-white mb-3">Your Next Steps</h3>
                     <ul className="space-y-2 text-sm text-slate-300 list-disc list-inside">
                        <li>Make sure to log your sleep from last night to keep your streak going.</li>
                        <li>Review your chart for patterns. Did poor sleep quality correlate with a later bedtime?</li>
                        <li>Is your bedtime goal realistic? Adjust it if you need to.</li>
                    </ul>
                </div>

                <div className="bg-slate-800/50 p-4 rounded-lg mb-8">
                    <div className="flex justify-between items-center">
                        <div>
                            <h3 className="text-lg font-semibold text-white">Bedtime Goal</h3>
                            <p className="text-sm text-slate-400">Set a target to build a consistent routine.</p>
                        </div>
                        <input 
                            type="time" 
                            value={bedtimeGoal}
                            onChange={handleGoalChange}
                            className="bg-slate-700 text-slate-200 rounded-lg p-2 border border-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            aria-label="Set your bedtime goal"
                        />
                    </div>
                </div>

                <h2 className="text-xl font-semibold text-white mb-4">Sleep Duration (Last 15 nights)</h2>
                {logs.length > 0 ? (
                    <SleepChart logs={logs} bedtimeGoal={bedtimeGoal} />
                ) : (
                    <div className="text-center bg-slate-900/50 p-10 rounded-lg">
                        <p className="text-slate-400">No sleep data logged yet. Start logging your sleep to see your progress chart.</p>
                    </div>
                )}
                
                <h2 className="text-xl font-semibold text-white mt-12 mb-4">Overall Averages</h2>
                {logs.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <StatCard 
                            icon={<ClockIcon className="w-6 h-6 text-white"/>}
                            label="Avg. Sleep Duration"
                            value={`${avgDuration.toFixed(1)} hrs`}
                            color="bg-indigo-500"
                        />
                        <StatCard 
                            icon={<StarIcon className="w-6 h-6 text-white"/>}
                            label="Avg. Sleep Quality"
                            value={avgQuality}
                            color="bg-amber-500"
                        />
                         <StatCard 
                            icon={<TrendingUpIcon className="w-6 h-6 text-white"/>}
                            label="Total Nights Logged"
                            value={`${logs.length}`}
                            color="bg-green-500"
                        />
                         <StatCard 
                            icon={<StarIcon className="w-6 h-6 text-white" style={{fill: 'currentColor'}} />}
                            label="Goal Adherence"
                            value={`${goalAdherence}%`}
                            color="bg-teal-500"
                        />
                    </div>
                ) : (
                     <div className="text-center bg-slate-900/50 p-10 rounded-lg">
                        <p className="text-slate-400">Log some sleep to see your stats.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProgressTab;