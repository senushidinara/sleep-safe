import React from 'react';
import { MoonIcon } from './icons';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-16 border-b border-slate-700/50">
          <a href="#" onClick={(e) => e.preventDefault()} aria-label="SleepSafe" className="flex items-center">
            <MoonIcon className="h-8 w-8 text-indigo-400" aria-hidden="true" />
            <span className="ml-3 text-2xl font-bold tracking-tight text-slate-100">SleepSafe</span>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;