export interface Message {
  role: 'user' | 'model' | 'error';
  text: string;
}

export interface SleepLog {
  id: number;
  date: string;
  duration: number;
  quality: 'Poor' | 'Fair' | 'Good' | 'Excellent';
  notes?: string;
  bedtime?: string;
}

export interface Reminder {
  id: number;
  task: string;
  datetime: string;
  completed: boolean;
  repeat?: 'none' | 'daily' | 'weekly' | 'monthly';
}
